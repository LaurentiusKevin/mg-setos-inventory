<?php

namespace App\Repositories\Admin\SystemUtility;

class MenuGroupRepository
{
    public function __construct()
    {
    }
}
