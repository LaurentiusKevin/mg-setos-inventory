<?php

namespace App\Repositories\Admin\SystemUtility;

class MenuRepository
{
    public function __construct()
    {
    }
}
