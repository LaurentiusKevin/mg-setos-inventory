<?php

namespace App\Repositories\Admin\MasterData;

class SatuanProductRepository
{

}
