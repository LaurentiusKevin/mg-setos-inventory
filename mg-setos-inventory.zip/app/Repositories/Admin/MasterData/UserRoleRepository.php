<?php

namespace App\Repositories\Admin\MasterData;

class UserRoleRepository
{

}
