<?php

namespace App\Repositories\Admin\Stock;

class SupplierRepository
{

}
