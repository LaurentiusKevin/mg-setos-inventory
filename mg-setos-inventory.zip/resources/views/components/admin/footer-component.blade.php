<footer class="c-footer">
    <div><a href="{{ url('') }}">Setos Purchasing Program</a> © {{ date('Y') }} NerualSys.</div>
{{--            <div class="ml-auto">Powered by&nbsp;<a href="https://coreui.io/">CoreUI</a></div>--}}
</footer>
