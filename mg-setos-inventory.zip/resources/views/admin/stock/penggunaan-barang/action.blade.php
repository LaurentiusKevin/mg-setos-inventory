<span class="text-nowrap">
    <button class="btn btn-ghost-info action-info" title="Info">
        <i class="fas fa-eye"></i>
    </button>
</span>
