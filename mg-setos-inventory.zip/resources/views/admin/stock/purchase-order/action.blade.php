<span class="text-nowrap">
    @if($data->received_item == 0)
        <button class="btn btn-ghost-danger action-delete" title="Hapus">
            <i class="fas fa-times"></i>
        </button>
    @endif
    <button class="btn btn-ghost-info action-info" title="Info">
        <i class="fas fa-info"></i>
    </button>
</span>
