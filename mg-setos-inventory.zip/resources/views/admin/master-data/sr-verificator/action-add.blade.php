<span class="text-nowrap">
    <button class="btn btn-ghost-success action-add" title="Add">
        <i class="fas fa-plus"></i>
    </button>
</span>
