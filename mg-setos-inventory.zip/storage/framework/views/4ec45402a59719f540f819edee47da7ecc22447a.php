<span class="text-nowrap">
    <?php if($data->verified_at == null): ?>
        <?php if($verification > 0): ?>
            <button class="btn btn-ghost-success action-verification" title="Verification">
            <i class="fas fa-check"></i>
        </button>
        <?php endif; ?>
        <button class="btn btn-ghost-warning action-edit" title="Edit SR">
            <i class="fas fa-edit"></i>
        </button>
    <?php endif; ?>
    <button class="btn btn-ghost-info action-info" title="Info">
        <i class="fas fa-info"></i>
    </button>
</span>
<?php /**PATH D:\Development\mg-setos-inventory\resources\views/admin/stock/store-requisition/action.blade.php ENDPATH**/ ?>