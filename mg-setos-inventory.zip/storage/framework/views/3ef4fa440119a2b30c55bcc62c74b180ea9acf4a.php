<!DOCTYPE html>
<html lang="id">
<head>
    <title>Store Requisition <?php echo e($info->invoice_number); ?></title>
    <link rel="stylesheet" href="<?php echo e(public_path('css/pdf/portrait.css')); ?>">
</head>
<body>
<header>
    <table style="width: 100%">
        <tr>
            <td class="header-brt" style="width: 30%">STORE REQUISITION</td>
            <td style="width: 20%"></td>
            <td rowspan="2" style="width: 50%">
                <img src="<?php echo e(public_path('icons/logo-mg-setos-hotel.png')); ?>" class="logo" alt="Logo" style="width: 60%">
            </td>
        </tr>
        <tr>
            <td class="invoice-number" style="height: 1cm">
                <span class="text-bold text-setos" style="font-size: 10px;">Nomor</span>
                <br><?php echo e($info->invoice_number); ?>

            </td>
        </tr>
    </table>
    <hr>
</header>

<footer-tdd>
    <table style="width: 100%">
        <tr>
            <td style="width: 40%">
                Tertanda Tangan Secara Digital
                <br>Pada: <?php echo e(date('d-m-Y, H:i:s',strtotime($info->updated_at))); ?>

                <br>
                <br><strong style="font-size: 13px"><?php echo e($info->penginput); ?></strong>
            </td>
            <?php $__currentLoopData = $verificator; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td style="width: 30%">
                    <?php echo e(($item->verified_at == null) ? ' ' : 'Tertanda Tangan Secara Digital'); ?>

                    <br><?php echo e(($item->verified_at == null) ? ' ' : 'Pada: '.date('d-m-Y, H:i:s',strtotime($item->verified_at))); ?>

                    <br>
                    <br><strong style="font-size: 13px"><?php echo e(ucfirst($item->verificator)); ?></strong>
                </td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    </table>
    <table style="width: 100%; margin-top: 1cm">
        <tr>
            <td>Dicetak oleh <?php echo e(auth()->user()->name); ?> (<?php echo e(date('d F Y - H:i:s')); ?>)</td>
        </tr>
    </table>
</footer-tdd>

<main>
    <table style="width: 100%">
        <tr>
            <td class="text-bold text-setos" style="width: 30%; font-size: 10px">Department</td>
            <td class="text-bold text-setos" style="width: 40%; font-size: 10px">Digunakan Untuk</td>
            <td class="text-bold text-setos" style="width: 30%; font-size: 10px">Catatan</td>
        </tr>
        <tr>
            <td style="font-size: 14px; vertical-align: top"><?php echo e($info->department ?? '-'); ?></td>
            <td style="font-size: 14px"><?php echo e($info->info_penggunaan); ?></td>
            <td style="font-size: 14px; vertical-align: top"><?php echo e($info->catatan ?? '-'); ?></td>
        </tr>
    </table>
    <hr>
    <table class="table-transaksi">
        <thead>
        <tr class="text-center">
            <th class="bg-setos" style="color: white; width: 8%">No</th>
            <th class="bg-setos" style="color: white; width: 40%">Produk</th>
            <th class="bg-setos" style="color: white; width: 20%">Quantity</th>
            <th class="bg-setos" style="color: white; width: 20%">Harga (Rp)</th>
            <th class="bg-setos" style="color: white; width: 20%">Total (Rp)</th>
        </tr>
        </thead>
        <tbody>
        <?php ($total = 0); ?>
        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="text-center"><?php echo e($key+1); ?></td>
                <td><?php echo e($item->product_name); ?></td>
                <td class="text-right"><?php echo e(number_format($item->quantity,0,',','.').' '.$item->satuan); ?></td>
                <td class="text-right"><?php echo e(number_format($item->price,0,',','.')); ?></td>
                <td class="text-right"><?php echo e(number_format($item->quantity * $item->price,0,',','.')); ?></td>
            </tr>
            <?php ($total += $item->quantity * $item->price); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
        <tr>
            <td colspan="4" class="text-right text-bold">Total</td>
            <td class="text-right text-bold"><?php echo e(number_format($total,0,',','.')); ?></td>
        </tr>
        </tfoot>
    </table>
</main>
</body>
</html>
<?php /**PATH D:\Development\mg-setos-inventory\resources\views/admin/stock/store-requisition/pdf.blade.php ENDPATH**/ ?>