<?php $__env->startSection('title','Master Data - User Role - Create'); ?>

<?php $__env->startSection('description',''); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item">Master Data</li>
    <li class="breadcrumb-item">User Role</li>
    <li class="breadcrumb-item active">Create</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header">
                    <strong>Create New User Role</strong>
                </div>
                <form id="formData">
                    <div class="card-body">
                        <div class="form-group">
                            <label for="iName">Nama</label>
                            <input type="text" class="form-control" name="name" id="iName" required>
                        </div>
                        <div class="form-group">
                            <label for="iInfo">Info</label>
                            <input type="text" class="form-control" name="info" id="iInfo">
                        </div>
                        <label for="t_i_menu">Menu</label>
                        <table class="table table-sm table-bordered table-hover" id="t_i_menu">
                            <thead>
                            <tr class="table-primary">
                                <th class="text-center">Nama Menu</th>
                                <th class="text-center" style="width: 10%">View</th>
                                <th class="text-center" style="width: 10%">Create</th>
                                <th class="text-center" style="width: 10%">Edit</th>
                                <th class="text-center" style="width: 10%">Delete</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="table-active">
                                    <th colspan="5"><?php echo e($group['name']); ?></th>
                                </tr>
                                <?php $__currentLoopData = $group['menu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th>&nbsp;&nbsp;<?php echo e($m['name']); ?></th>
                                        <td class="text-center">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="view[]" value="<?php echo e($m['id']); ?>" id="view-<?php echo e($m['id']); ?>">
                                                <label class="form-check-label" for="view-<?php echo e($m['id']); ?>"></label>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="create[]" value="<?php echo e($m['id']); ?>" id="create-<?php echo e($m['id']); ?>">
                                                <label class="form-check-label" for="create-<?php echo e($m['id']); ?>"></label>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="edit[]" value="<?php echo e($m['id']); ?>" id="edit-<?php echo e($m['id']); ?>">
                                                <label class="form-check-label" for="edit-<?php echo e($m['id']); ?>"></label>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="delete[]" value="<?php echo e($m['id']); ?>" id="delete-<?php echo e($m['id']); ?>">
                                                <label class="form-check-label" for="delete-<?php echo e($m['id']); ?>"></label>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer bg-gradient-secondary">
                        <div class="row justify-content-between">
                            <div class="col-sm-12 col-md-4 col-lg-2">
                                <a href="<?php echo e(route('admin.master-data.user-role.view.index')); ?>" class="btn btn-block btn-outline-primary"><i class="fas fa-arrow-left mr-2"></i>Kembali</a>
                            </div>
                            <div class="col-sm-12 col-md-4 col-lg-2 mt-2 mt-lg-0 mt-sm-2">
                                <button type="submit" class="btn btn-block btn-success"><i class="fas fa-check mr-2"></i>Simpan</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script type="text/javascript">
        const name = () => document.getElementById('iName').value
        const segment_name = () => document.getElementById('iSegmentName').value
        const icon = () => document.getElementById('iIcon').value
        const order = () => document.getElementById('iOrder').value

        document.addEventListener("DOMContentLoaded", () => {
            $('#formData').on('submit', function (event) {
                event.preventDefault()

                axios({
                    url: '<?php echo e(route('admin.master-data.user-role.api.store')); ?>',
                    method: 'post',
                    data: $(this).serialize()
                }).then(response => {
                    if (response.data.status === 'success') {
                        Swal.fire({
                            icon: 'success',
                            title: 'Data Tersimpan',
                            timer: 1200,
                            showConfirmButton: false,
                            willClose(popup) {
                                window.location = response.data.redirect
                            }
                        });
                    } else {
                        Swal.fire({
                            icon: 'warning',
                            title: 'Data Gagal Tersimpan'
                        });
                    }
                }).catch(error => {
                    Swal.fire({
                        icon: 'error',
                        title: 'Terdapat Kesalahan Pada System',
                        text: error.response.data.message,
                    });
                })
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin._layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\mg-setos-inventory\resources\views/admin/master-data/user-role/create.blade.php ENDPATH**/ ?>