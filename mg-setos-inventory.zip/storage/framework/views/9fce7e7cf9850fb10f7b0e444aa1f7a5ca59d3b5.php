<!DOCTYPE html>
<html lang="id">
<head>
    <base href="<?php echo e(url('/')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <meta name="description" content="MG Setos - Inventory - Stock Management System <?php if (! empty(trim($__env->yieldContent('description')))): ?> - <?php echo $__env->yieldContent('description'); ?> <?php endif; ?>">
    <meta name="author" content="Laurentius Kevin">
    <meta name="keyword" content="MgSetos,Hotel,Inventory,StockManagement,System">
    <title>MG Setos <?php if (! empty(trim($__env->yieldContent('title')))): ?> - <?php echo $__env->yieldContent('title'); ?> <?php endif; ?></title>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    <link href="<?php echo e(asset('icons/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/admin/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/sweetalert2-default.css')); ?>" rel="stylesheet">
    <style>
        .c-sidebar .c-sidebar-brand, .c-sidebar .c-sidebar-header {
            background: #331c45;
        }
        .c-sidebar {
            position: relative;
            display: -ms-flexbox;
            display: flex;
            -ms-flex: 0 0 256px;
            flex: 0 0 256px;
            -ms-flex-direction: column;
            flex-direction: column;
            -ms-flex-order: -1;
            order: -1;
            width: 256px;
            padding: 0;
            box-shadow: none;
            color: #fff;
            background: #6C3D94;
            transition: box-shadow 0.3s 0.15s, margin-left 0.3s, margin-right 0.3s, width 0.3s, z-index 0s ease 0.3s, -webkit-transform 0.3s;
            transition: box-shadow 0.3s 0.15s, transform 0.3s, margin-left 0.3s, margin-right 0.3s, width 0.3s, z-index 0s ease 0.3s;
            transition: box-shadow 0.3s 0.15s, transform 0.3s, margin-left 0.3s, margin-right 0.3s, width 0.3s, z-index 0s ease 0.3s, -webkit-transform 0.3s;
        }
    </style>
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body class="c-app">
<?php if (isset($component)) { $__componentOriginal068db50c76a94ac9d3c3de8fa51f27e472def530 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\SidebarComponent::class, []); ?>
<?php $component->withName('admin.sidebar-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal068db50c76a94ac9d3c3de8fa51f27e472def530)): ?>
<?php $component = $__componentOriginal068db50c76a94ac9d3c3de8fa51f27e472def530; ?>
<?php unset($__componentOriginal068db50c76a94ac9d3c3de8fa51f27e472def530); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<div class="c-wrapper c-fixed-components">
    <?php if (isset($component)) { $__componentOriginalab6f85622ba4144c8a2486bbb304eb4ca7438a74 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\NavbarComponent::class, []); ?>
<?php $component->withName('admin.navbar-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalab6f85622ba4144c8a2486bbb304eb4ca7438a74)): ?>
<?php $component = $__componentOriginalab6f85622ba4144c8a2486bbb304eb4ca7438a74; ?>
<?php unset($__componentOriginalab6f85622ba4144c8a2486bbb304eb4ca7438a74); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <div class="c-body">
        <main class="c-main">
            <div class="container-fluid">
                <div class="fade-in">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </main>
        <?php if (isset($component)) { $__componentOriginal9e6786ccfaee85663b003742946f942c953894e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\FooterComponent::class, []); ?>
<?php $component->withName('admin.footer-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal9e6786ccfaee85663b003742946f942c953894e3)): ?>
<?php $component = $__componentOriginal9e6786ccfaee85663b003742946f942c953894e3; ?>
<?php unset($__componentOriginal9e6786ccfaee85663b003742946f942c953894e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    </div>
</div>
<script src="<?php echo e(asset('js/admin/coreui.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/axios.js')); ?>"></script>
<script src="<?php echo e(asset('js/sweetalert2.js')); ?>"></script>
<script type="text/javascript">
    axios.defaults.headers.common['X-CSRF-TOKEN'] = document.querySelector('meta[name="csrf-token"]').content;

    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    })

    const Loader = {
        button: function (btn, classData, text = null) {
            if (text !== null) {
                btn.html(text);
            }

            if (btn.hasClass(classData)) {
                btn.removeClass(classData);
                btn.prop("disabled", false);
            } else {
                btn.addClass(classData);
                btn.prop("disabled", true);
            }
        },
        label: function (label, classData) {
            if (label.hasClass(classData)) {
                label.removeClass(classData);
            } else {
                label.addClass(classData);
            }
        }
    }
</script>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>
<?php /**PATH D:\Development\mg-setos-inventory\resources\views/admin/_layout.blade.php ENDPATH**/ ?>