<span class="text-nowrap">
    <button class="btn btn-ghost-info action-edit" title="Edit">
        <i class="fas fa-edit"></i>
    </button>
    <button class="btn btn-ghost-danger action-delete" title="Delete">
        <i class="fas fa-times"></i>
    </button>
</span>
<?php /**PATH D:\Development\mg-setos-inventory\resources\views/admin/master-data/satuan-product/action.blade.php ENDPATH**/ ?>