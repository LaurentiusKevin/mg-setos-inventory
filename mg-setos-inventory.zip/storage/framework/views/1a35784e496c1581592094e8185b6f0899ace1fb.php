<div class="c-sidebar c-sidebar-dark c-sidebar-fixed c-sidebar-lg-show" id="sidebar">
    <div class="c-sidebar-brand d-lg-down-none">
        <div class="c-sidebar-brand-full">
            <img class="img-fluid" src="<?php echo e(asset('icons/logo-mg-setos-hotel.webp')); ?>" alt="logo-mg-setos" style="width: 118px">
        </div>
        <div class="c-sidebar-brand-minimized">
            <img class="img-fluid" src="<?php echo e(asset('icons/logo-mg-setos-hotel.webp')); ?>" alt="logo-mg-setos" style="width: 46px">
        </div>
    </div>
    <ul class="c-sidebar-nav">
        <li class="c-sidebar-nav-item">
            <a class="c-sidebar-nav-link" href="<?php echo e(url('admin')); ?>">
                <i class="fa fa-tachometer-alt c-sidebar-nav-icon"></i> Dashboard
            </a>
        </li>
        <li class="c-sidebar-nav-title">Menu</li>
        <?php $__currentLoopData = $sidebar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="c-sidebar-nav-dropdown">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="c-sidebar-nav-icon <?php echo e($item['group']['icon']); ?>"></i>
                    <?php echo e($item['group']['name']); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php $__currentLoopData = $item['menu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="c-sidebar-nav-item">
                            <a class="c-sidebar-nav-link" href="<?php echo e(url($menu->url)); ?>">
                                <span class="c-sidebar-nav-icon"></span> <?php echo e($menu->name); ?>

                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <button class="c-sidebar-minimizer c-class-toggler" type="button" data-target="_parent" data-class="c-sidebar-minimized"></button>
</div>
<?php /**PATH D:\Development\mg-setos-inventory\resources\views/components/admin/sidebar-component.blade.php ENDPATH**/ ?>