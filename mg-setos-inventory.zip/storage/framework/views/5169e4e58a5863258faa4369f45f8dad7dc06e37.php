<span class="text-nowrap">
    <button class="btn btn-ghost-success action-add" title="Add">
        <i class="fas fa-plus"></i>
    </button>
</span>
<?php /**PATH D:\Development\mg-setos-inventory\resources\views/admin/master-data/sr-verificator/action-add.blade.php ENDPATH**/ ?>