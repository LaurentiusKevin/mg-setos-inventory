<span class="text-nowrap">
    <?php if($data->completed_at == null): ?>
        <button class="btn btn-ghost-success action-process" title="Invoicing Process">
            <i class="fas fa-truck-loading"></i>
        </button>
    <?php else: ?>
        <button class="btn btn-ghost-info action-detail" title="Detail">
            <i class="fas fa-info"></i>
        </button>
    <?php endif; ?>
</span>
<?php /**PATH D:\Development\mg-setos-inventory\resources\views/admin/purchasing/invoicing/action.blade.php ENDPATH**/ ?>