<?php $__env->startSection('title','Purchasing - Invoicing - Info'); ?>

<?php $__env->startSection('description',''); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item">Purchasing</li>
    <li class="breadcrumb-item">Invoicing</li>
    <li class="breadcrumb-item active">Info</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <strong>Info</strong>
                </div>
                <div class="card-body">
                    <dl class="row">
                        <dt class="col-sm-2">Nomor Invoice</dt>
                        <dd class="col-sm-10 font-weight-bold"><?php echo e($info->invoice_number_invoicing); ?></dd>

                        <dt class="col-sm-2">Info Penggunaan</dt>
                        <dd class="col-sm-10"><?php echo e($info->info_penggunaan); ?></dd>

                        <dt class="col-sm-2">Catatan</dt>
                        <dd class="col-sm-10"><?php echo e($info->catatan ?? '-'); ?></dd>
                    </dl>
                </div>
                <div class="card-footer">
                    <div class="d-flex justify-content-between">
                        <div class="p-2 bd-highlight">
                            <a href="<?php echo e(route('admin.purchasing.invoicing.view.index')); ?>" class="btn btn-block btn-outline-primary"><i class="fas fa-arrow-left mr-2"></i>Kembali</a>
                        </div>
                        <div class="p-2 bd-highlight">
                            <div class="btn-group" role="group" aria-label="Basic example">
                                <a href="<?php echo e(route('admin.purchasing.invoicing.view.invoice-details',[$info->id])); ?>" target="_blank" class="btn btn-outline-primary"><i class="fas fa-file-pdf mr-2"></i> Detail</a>
                                <a href="<?php echo e(route('admin.purchasing.invoicing.view.invoice-summary',[$info->id])); ?>" target="_blank" class="btn btn-outline-primary"><i class="fas fa-file-pdf mr-2"></i> Summary</a>
                            </div>
                        </div>
                    </div>











                </div>
            </div>
        </div>

        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <strong>Produk</strong>
                </div>
                <div class="card-body">
                    <table class="table table-bordered table-hover">
                        <thead>
                        <tr>
                            <th>No</th>
                            <th>Kode</th>
                            <th>Produk</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Penginput</th>
                            <th>Tanggal</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-nowrap" style="width: 2%"><?php echo e($key+1); ?></td>
                                <td class="font-weight-bold text-nowrap" style="width: 5%"><?php echo e($item->product_code); ?></td>
                                <td><?php echo e($item->product_name); ?></td>
                                <td class="text-right"><?php echo e(number_format($item->quantity_sent,0,',','.').' '.$item->satuan); ?></td>
                                <td class="text-right">Rp <?php echo e(number_format($item->price,0,',','.')); ?></td>
                                <td><?php echo e($item->penginput); ?></td>
                                <td class="text-nowrap" style="width: 5%"><?php echo e(date('d F Y, H:i:s',strtotime($item->invoicing_created_at))); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin._layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\mg-setos-inventory\resources\views/admin/purchasing/invoicing/info.blade.php ENDPATH**/ ?>