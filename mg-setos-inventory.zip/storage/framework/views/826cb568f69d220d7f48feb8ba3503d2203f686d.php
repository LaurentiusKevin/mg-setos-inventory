<?php $__env->startSection('title','Purchasing - Supplier - Info'); ?>

<?php $__env->startSection('description',''); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item">Purchasing</li>
    <li class="breadcrumb-item">Supplier</li>
    <li class="breadcrumb-item active">Info</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('css/filepond.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/fancybox.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <strong>Info</strong>
                </div>
                <div class="card-body">
                    <div class="d-flex flex-row bd-highlight">
                        <div class="p-2 bd-highlight"><img id="info_logo" src="<?php echo e($data->supplier->logo == null ? asset('icons/picture.svg') : url("admin/master-data/supplier/api/get-image/{$data->supplier->logo}")); ?>" alt="image" style="width: 75px"></div>
                        <div class="p-2 flex-grow-1 bd-highlight">
                            <div class="row">
                                <div class="col-sm-12 col-md-4 col-lg-3">
                                    <div class="form-group">
                                        <label for="info_supplier">Nama Supplier</label>
                                        <br><span class="font-weight-bold" id="info_supplier"><?php echo e($data->supplier->name); ?></span>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-4 col-lg-3">
                                    <div class="form-group">
                                        <label for="info_telp">Telp.</label>
                                        <br><span class="font-weight-bold" id="info_telp"><?php echo e($data->supplier->phone); ?></span>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-4 col-lg-3">
                                    <div class="form-group">
                                        <label for="info_alamat">Alamat</label>
                                        <br><span class="font-weight-bold" id="info_alamat"><?php echo e($data->supplier->address); ?></span>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-4 col-lg-3">
                                    <div class="form-group">
                                        <label for="info_cp_nama">Nama CP</label>
                                        <br><span class="font-weight-bold" id="info_cp_nama"><?php echo e($data->supplier->contact_person_name); ?></span>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-4 col-lg-3">
                                    <div class="form-group">
                                        <label for="info_cp_telp">Telp CP</label>
                                        <br><span class="font-weight-bold" id="info_cp_telp"><?php echo e($data->supplier->contact_person_phone); ?></span>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-4 col-lg-3">
                                    <div class="form-group">
                                        <label for="info_catatan">Catatan</label>
                                        <br><span class="font-weight-bold" id="info_catatan"><?php echo e($data->supplier->info ?? '-'); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <div class="row justify-content-between">
                        <div class="col-sm-12 col-md-4 col-lg-2">
                            <a href="<?php echo e(route('admin.purchasing.purchase-order.view.index')); ?>" class="btn btn-block btn-outline-primary"><i class="fas fa-arrow-left mr-2"></i>Kembali</a>
                        </div>
                        <div class="col-sm-12 col-md-3 col-lg-2">
                            <a href="<?php echo e(route('admin.purchasing.purchase-order.view.invoice',[$data->id])); ?>" target="_blank" class="btn btn-outline-primary btn-block"><i class="fas fa-file-pdf mr-2"></i> PDF</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <strong>Produk</strong>
                </div>
                <div class="card-body">
                    <table class="table table-bordered table-hover">
                        <thead>
                        <tr>
                            <th>Produk</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Total</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $data->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->product->name); ?></td>
                                <td class="text-right"><?php echo e(number_format($item->quantity,0,',','.').' '.$item->product->satuan->nama); ?></td>
                                <td class="text-right">
                                    <div class="d-flex justify-content-between"><div class="p-2 bd-highlight">Rp </div><div class="p-2 bd-highlight"><?php echo e(number_format($item->price,0,',','.')); ?></div></div>
                                </td>
                                <td class="text-right"><?php echo e(number_format($item->total_price,0,',','.')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr class="bg-info">
                            <td class="font-weight-bold" colspan="3">Total</td>
                            <td class="text-right font-weight-bold"><?php echo e(number_format($data->total_price,0,',','.')); ?></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/numeral.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin._layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\mg-setos-inventory\resources\views/admin/stock/purchase-order/info.blade.php ENDPATH**/ ?>