<?php $__env->startSection('title','Master Data - User Aplikasi - Create'); ?>

<?php $__env->startSection('description',''); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item">Master Data</li>
    <li class="breadcrumb-item">User Aplikasi</li>
    <li class="breadcrumb-item active">Create</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header">
                    <strong>Create New User</strong>
                </div>
                <form id="formData">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12 col-md-4 col-lg-4">
                                <div class="form-group">
                                    <label for="iRole">Role <span class="text-danger">*</span></label>
                                    <select class="form-control" name="master_roles_id" id="iRole" required>
                                        <option value="">-- Pilih Role --</option>
                                        <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($r->id); ?>"><?php echo e($r->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-4 col-lg-4">
                                <div class="form-group">
                                    <label for="i_department">Department</label>
                                    <select class="form-control" name="department" id="i_department">
                                        <option value="">-- Pilih Department --</option>
                                        <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="iName">Name <span class="text-danger">*</span></label>
                            <input id="iName" name="name" type="text" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="iEmail">Email</label>
                            <input id="iEmail" name="email" type="email" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="iUsername">Username <span class="text-danger">*</span></label>
                            <input id="iUsername" name="username" type="text" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="iPassword">Password <span class="text-danger">*</span></label>
                            <input id="iPassword" name="password" type="password" class="form-control" required>
                        </div>
                    </div>
                    <div class="card-footer bg-gradient-secondary">
                        <div class="row justify-content-between">
                            <div class="col-sm-12 col-md-4 col-lg-2">
                                <a href="<?php echo e(route('admin.master-data.user-aplikasi.view.index')); ?>" class="btn btn-block btn-outline-primary"><i class="fas fa-arrow-left mr-2"></i>Kembali</a>
                            </div>
                            <div class="col-sm-12 col-md-4 col-lg-2 mt-2 mt-lg-0 mt-sm-2">
                                <button type="submit" class="btn btn-block btn-success"><i class="fas fa-check mr-2"></i>Simpan</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        const role = () => document.getElementById('iRole').value
        const department = () => document.getElementById('i_department').value
        const name = () => document.getElementById('iName').value
        const email = () => document.getElementById('iEmail').value
        const username = () => document.getElementById('iUsername').value
        const password = () => document.getElementById('iPassword').value

        document.addEventListener("DOMContentLoaded", () => {
            document.getElementById('formData').addEventListener('submit', event => {
                event.preventDefault()

                axios({
                    url: '<?php echo e(route('admin.master-data.user-aplikasi.api.store')); ?>',
                    method: 'post',
                    data: {
                        role: role(),
                        department: department(),
                        name: name(),
                        email: email(),
                        username: username(),
                        password: password(),
                    }
                }).then(response => {
                    if (response.data.status === 'success') {
                        Swal.fire({
                            icon: 'success',
                            title: 'Data Tersimpan',
                            timer: 1200,
                            showConfirmButton: false,
                            willClose(popup) {
                                window.location = response.data.redirect
                            }
                        });
                    } else {
                        Swal.fire({
                            icon: 'warning',
                            title: response.data.message
                        });
                    }
                }).catch(error => {
                    Swal.fire({
                        icon: 'error',
                        title: 'Terdapat Kesalahan Pada System',
                        text: error.response.data.message,
                    });
                })
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin._layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\mg-setos-inventory\resources\views/admin/master-data/user-aplikasi/create.blade.php ENDPATH**/ ?>