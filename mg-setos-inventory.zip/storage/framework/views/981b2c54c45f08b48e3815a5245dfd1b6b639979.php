<footer class="c-footer">
    <div><a href="<?php echo e(url('')); ?>">Setos Purchasing Program</a> © <?php echo e(date('Y')); ?> NerualSys.</div>

</footer>
<?php /**PATH D:\Development\mg-setos-inventory\resources\views/components/admin/footer-component.blade.php ENDPATH**/ ?>