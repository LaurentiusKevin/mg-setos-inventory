<span class="text-nowrap">
    <button class="btn btn-ghost-info action-info" title="Info">
        <i class="fas fa-info"></i>
    </button>
</span>
<?php /**PATH D:\Development\mg-setos-inventory\resources\views/admin/stock/purchase-order/action.blade.php ENDPATH**/ ?>