create view TABLE_CONSTRAINTS as
(select (`cat`.`name` collate utf8_tolower_ci)                      AS `CONSTRAINT_CATALOG`,
        (`sch`.`name` collate utf8_tolower_ci)                      AS `CONSTRAINT_SCHEMA`,
        `idx`.`name`                                                AS `CONSTRAINT_NAME`,
        (`sch`.`name` collate utf8_tolower_ci)                      AS `TABLE_SCHEMA`,
        (`tbl`.`name` collate utf8_tolower_ci)                      AS `TABLE_NAME`,
        if((`idx`.`type` = 'PRIMARY'), 'PRIMARY KEY', `idx`.`type`) AS `CONSTRAINT_TYPE`
 from (((`mysql`.`indexes` `idx` join `mysql`.`tables` `tbl` on ((`idx`.`table_id` = `tbl`.`id`))) join `mysql`.`schemata` `sch` on ((`tbl`.`schema_id` = `sch`.`id`)))
          join `mysql`.`catalogs` `cat`
               on (((`cat`.`id` = `sch`.`catalog_id`) and (`idx`.`type` in ('PRIMARY', 'UNIQUE')))))
 where (can_access_table(`sch`.`name`, `tbl`.`name`) and is_visible_dd_object(`tbl`.`hidden`, `idx`.`hidden`)))
union
(select (`cat`.`name` collate utf8_tolower_ci) AS `CONSTRAINT_CATALOG`,
        (`sch`.`name` collate utf8_tolower_ci) AS `CONSTRAINT_SCHEMA`,
        (`fk`.`name` collate utf8_tolower_ci)  AS `CONSTRAINT_NAME`,
        (`sch`.`name` collate utf8_tolower_ci) AS `TABLE_SCHEMA`,
        (`tbl`.`name` collate utf8_tolower_ci) AS `TABLE_NAME`,
        'FOREIGN KEY'                          AS `CONSTRAINT_TYPE`
 from (((`mysql`.`foreign_keys` `fk` join `mysql`.`tables` `tbl` on ((`fk`.`table_id` = `tbl`.`id`))) join `mysql`.`schemata` `sch` on ((`tbl`.`schema_id` = `sch`.`id`)))
          join `mysql`.`catalogs` `cat` on ((`cat`.`id` = `sch`.`catalog_id`)))
 where (can_access_table(`sch`.`name`, `tbl`.`name`) and is_visible_dd_object(`tbl`.`hidden`)));

